<?php
include "../controllers/basic_functions.php";
session_start();
    redirectPagewithAlert("dashboard_department_head_mobile.php", "Please login in the browser for User Management");
?>