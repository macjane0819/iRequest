<?php
/**if(isset($_SESSION['user']) && isset($_SESSION['role_type'])){
    if($_SESSION['role_type'] == "Admin"){
        header("LOCATION: dashboard_admin.php");
    }elseif($_SESSION['role_type'] == "Department Head"){
        header("LOCATION: dashboard_department_head.php");
    }else{
        header("LOCATION: dashboard_department_member.php");
    }
} */
?>