<?php
include "controllers/basic_functions.php";
session_start();
    redirectPagewithAlert("dashboard_department_head.php", "Please login in the mobile application to make reservation");
?>